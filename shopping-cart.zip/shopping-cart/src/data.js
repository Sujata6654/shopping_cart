const data = {
    products: [
      {
        id: '1',
        name: 'Tablet',
        price: 8000,
        image: 'https://picsum.photos/id/668/4133/2745',
      },
      {
        id: '2',
        name: 'Old Watch',
        price: 400,
        image: 'https://picsum.photos/id/175/2896/1944',
      },
      {
        id: '3',
        name: 'W Shoes',
        price: 890,
        image: 'https://picsum.photos/id/21/3008/2008',
      },
      {
        id: '4',
        name: 'W Shoes',
        price: 250,
        image: 'https://picsum.photos/id/30/1280/901',
      },
    ],
  };
  export default data;